import streamlit as st
from transformers import pipeline

classifier = pipeline("text-classification", model="distilbert-base-uncased-finetuned-sst-2-english")

st.title("📰 Fake News Detection (Demo Project)")
st.write("This is a demo NLP project using a Transformer model.")

text = st.text_area("Enter news text")

if st.button("Analyze"):
    if text.strip() == "":
        st.warning("Please enter some text")
    else:
        result = classifier(text)
        st.success(f"Prediction: {result[0]['label']} (Confidence: {round(result[0]['score'],2)})")
